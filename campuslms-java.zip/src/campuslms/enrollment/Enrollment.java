package campuslms.enrollment;

import campuslms.course.Course;
import campuslms.user.Student;
import java.time.LocalDate;

/** Association class linking one Student to one Course. */
public class Enrollment {
    private String enrollmentId;
    private Student student;
    private Course course;
    private LocalDate enrolledOn;
    private EnrollmentStatus status;

    public Enrollment(String enrollmentId, Student student, Course course,
                      LocalDate enrolledOn, EnrollmentStatus status) {
        this.enrollmentId = enrollmentId;
        this.student = student;
        this.course = course;
        this.enrolledOn = enrolledOn;
        this.status = status;
    }

    public String getEnrollmentId() { return enrollmentId; }
    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public LocalDate getEnrolledOn() { return enrolledOn; }
    public EnrollmentStatus getStatus() { return status; }

    public void updateStatus(EnrollmentStatus status) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
