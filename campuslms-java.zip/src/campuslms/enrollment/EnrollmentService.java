package campuslms.enrollment;

import campuslms.course.CourseService;
import campuslms.repository.EnrollmentRepository;
import campuslms.user.UserService;

/** Manages student-course enrollment records. */
public class EnrollmentService {
    private EnrollmentRepository enrollmentRepository;
    private UserService userService;
    private CourseService courseService;

    public EnrollmentService(EnrollmentRepository enrollmentRepository,
                             UserService userService, CourseService courseService) {
        this.enrollmentRepository = enrollmentRepository;
        this.userService = userService;
        this.courseService = courseService;
    }

    public Enrollment enroll(String studentId, String courseId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

}
