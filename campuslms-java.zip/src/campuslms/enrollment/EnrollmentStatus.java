package campuslms.enrollment;

/** Lifecycle state of a student's enrollment in a course. */
public enum EnrollmentStatus {
    ACTIVE,
    DROPPED,
    COMPLETED
}
