package campuslms.assignment;

import campuslms.course.CourseService;
import campuslms.notification.NotificationService;
import campuslms.repository.AssignmentRepository;
import campuslms.user.UserService;
import java.time.LocalDate;
import java.util.List;

/** Creates, updates and retrieves assignments; requests new-assignment notifications. */
public class AssignmentService {
    private AssignmentRepository assignmentRepository;
    private CourseService courseService;
    private UserService userService;
    private NotificationService notificationService;

    public AssignmentService(AssignmentRepository assignmentRepository,
                             CourseService courseService,
                             UserService userService,
                             NotificationService notificationService) {
        this.assignmentRepository = assignmentRepository;
        this.courseService = courseService;
        this.userService = userService;
        this.notificationService = notificationService;
    }

    public Assignment createAssignment(String instructorId, String courseId, String title,
                                       String description, LocalDate dueDate) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public Assignment getAssignment(String assignmentId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public List<Assignment> getCourseAssignments(String courseId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public void updateAssignment(String assignmentId, String title, String description,
                                 LocalDate dueDate, double maxPoints) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
