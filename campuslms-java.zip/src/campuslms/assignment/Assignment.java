package campuslms.assignment;

import campuslms.course.Course;
import java.time.LocalDate;

/** An assignment that belongs to exactly one Course. */
public class Assignment {
    private String assignmentId;
    private String title;
    private String description;
    private LocalDate dueDate;
    private double maxPoints;
    private Course course;

    public Assignment(String assignmentId, String title, String description,
                      LocalDate dueDate, double maxPoints, Course course) {
        this.assignmentId = assignmentId;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.maxPoints = maxPoints;
        this.course = course;
    }

    public String getAssignmentId() { return assignmentId; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDate getDueDate() { return dueDate; }
    public double getMaxPoints() { return maxPoints; }
    public Course getCourse() { return course; }

    public void updateAssignment(String title, String description,
                                 LocalDate dueDate, double maxPoints) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
