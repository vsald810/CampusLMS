package campuslms.grading;

import campuslms.submission.Submission;
import campuslms.user.Instructor;
import java.time.LocalDateTime;

/** Score and feedback given by an Instructor for one Submission. */
public class Grade {
    private String gradeId;
    private Submission submission;
    private Instructor gradedBy;
    private double points;
    private String feedback;
    private LocalDateTime gradedAt;

    public Grade(String gradeId, Submission submission, Instructor gradedBy,
                 double points, String feedback, LocalDateTime gradedAt) {
        this.gradeId = gradeId;
        this.submission = submission;
        this.gradedBy = gradedBy;
        this.points = points;
        this.feedback = feedback;
        this.gradedAt = gradedAt;
    }

    public String getGradeId() { return gradeId; }
    public Submission getSubmission() { return submission; }
    public Instructor getGradedBy() { return gradedBy; }
    public double getPoints() { return points; }
    public String getFeedback() { return feedback; }
    public LocalDateTime getGradedAt() { return gradedAt; }

    public void updateGrade(double points, String feedback) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
