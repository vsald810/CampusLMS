package campuslms.grading;

import campuslms.notification.NotificationService;
import campuslms.repository.GradeRepository;
import campuslms.submission.SubmissionService;
import campuslms.user.UserService;

/** Records grades and feedback; makes grades available to students. */
public class GradingService {
    private GradeRepository gradeRepository;
    private SubmissionService submissionService;
    private UserService userService;
    private NotificationService notificationService;

    public GradingService(GradeRepository gradeRepository,
                          SubmissionService submissionService,
                          UserService userService,
                          NotificationService notificationService) {
        this.gradeRepository = gradeRepository;
        this.submissionService = submissionService;
        this.userService = userService;
        this.notificationService = notificationService;
    }

    public Grade gradeSubmission(String instructorId, String submissionId,
                                 double points, String feedback) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

}
