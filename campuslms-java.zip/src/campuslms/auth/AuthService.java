package campuslms.auth;

import campuslms.user.Instructor;
import campuslms.user.Student;
import campuslms.user.User;
import campuslms.user.UserService;

/** Registration, login, logout and role checks. */
public class AuthService {
    private UserService userService;

    public AuthService(UserService userService) {
        this.userService = userService;
    }

    public User login(String email, String password) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public void logout(String userId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public Student registerStudent(String fullName, String email, String password) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public Instructor registerInstructor(String fullName, String email, String password) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

}
