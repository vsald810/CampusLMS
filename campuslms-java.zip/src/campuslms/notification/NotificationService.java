package campuslms.notification;

import campuslms.repository.NotificationRepository;
import campuslms.user.UserService;
import java.util.List;

/** Creates and retrieves notifications requested by other modules. */
public class NotificationService {
    private NotificationRepository notificationRepository;
    private UserService userService;

    public NotificationService(NotificationRepository notificationRepository,
                               UserService userService) {
        this.notificationRepository = notificationRepository;
        this.userService = userService;
    }

    public Notification createNotification(String recipientId, String message) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public Notification getNotification(String notificationId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public List<Notification> getUserNotifications(String userId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public void markNotificationAsRead(String notificationId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
