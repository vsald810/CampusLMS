package campuslms.notification;

import campuslms.user.User;
import java.time.LocalDateTime;

/** A message addressed to one User. */
public class Notification {
    private String notificationId;
    private User recipient;
    private String message;
    private LocalDateTime createdAt;
    private boolean read;

    public Notification(String notificationId, User recipient, String message,
                        LocalDateTime createdAt) {
        this.notificationId = notificationId;
        this.recipient = recipient;
        this.message = message;
        this.createdAt = createdAt;
        this.read = false;
    }

    public String getNotificationId() { return notificationId; }
    public User getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public boolean isRead() { return read; }

    public void markAsRead() {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
