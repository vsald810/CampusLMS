package campuslms.repository;

import campuslms.submission.Submission;
import java.util.List;
import java.util.Optional;

/** Data-access contract for Submission records. */
public interface SubmissionRepository {
    Optional<Submission> findById(String submissionId);
    List<Submission> findByAssignmentId(String assignmentId);
    List<Submission> findByStudentId(String studentId);
    void save(Submission submission);
}
