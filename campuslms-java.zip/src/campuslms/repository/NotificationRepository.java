package campuslms.repository;

import campuslms.notification.Notification;
import java.util.List;
import java.util.Optional;

/** Data-access contract for Notification records. */
public interface NotificationRepository {
    Optional<Notification> findById(String notificationId);
    List<Notification> findByUserId(String userId);
    void save(Notification notification);
}
