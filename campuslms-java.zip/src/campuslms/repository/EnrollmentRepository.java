package campuslms.repository;

import campuslms.enrollment.Enrollment;
import java.util.List;
import java.util.Optional;

/** Data-access contract for Enrollment records. */
public interface EnrollmentRepository {
    Optional<Enrollment> findById(String enrollmentId);
    Optional<Enrollment> findByStudentIdAndCourseId(String studentId, String courseId);
    List<Enrollment> findByStudentId(String studentId);
    List<Enrollment> findByCourseId(String courseId);
    void save(Enrollment enrollment);
}
