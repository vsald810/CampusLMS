package campuslms.repository;

import campuslms.grading.Grade;
import java.util.List;
import java.util.Optional;

/** Data-access contract for Grade records. */
public interface GradeRepository {
    Optional<Grade> findById(String gradeId);
    Optional<Grade> findBySubmissionId(String submissionId);
    List<Grade> findByStudentId(String studentId);
    void save(Grade grade);
}
