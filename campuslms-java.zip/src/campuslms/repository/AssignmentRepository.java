package campuslms.repository;

import campuslms.assignment.Assignment;
import java.util.List;
import java.util.Optional;

/** Data-access contract for Assignment records. */
public interface AssignmentRepository {
    Optional<Assignment> findById(String assignmentId);
    List<Assignment> findByCourseId(String courseId);
    void save(Assignment assignment);
}
