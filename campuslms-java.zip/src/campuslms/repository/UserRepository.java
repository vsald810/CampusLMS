package campuslms.repository;

import campuslms.user.User;
import java.util.Optional;

/** Data-access contract for User records. */
public interface UserRepository {
    Optional<User> findById(String userId);
    Optional<User> findByEmail(String email);
    void save(User user);
}
