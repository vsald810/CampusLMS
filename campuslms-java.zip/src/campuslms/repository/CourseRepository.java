package campuslms.repository;

import campuslms.course.Course;
import java.util.List;
import java.util.Optional;

/** Data-access contract for Course records. */
public interface CourseRepository {
    Optional<Course> findById(String courseId);
    List<Course> findAll();
    List<Course> findByInstructorId(String instructorId);
    void save(Course course);
}
