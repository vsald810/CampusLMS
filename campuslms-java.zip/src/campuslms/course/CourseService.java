package campuslms.course;

import campuslms.repository.CourseRepository;
import campuslms.user.UserService;
import java.util.List;

/** Creates, retrieves and updates courses. */
public class CourseService {
    private CourseRepository courseRepository;
    private UserService userService;

    public CourseService(CourseRepository courseRepository, UserService userService) {
        this.courseRepository = courseRepository;
        this.userService = userService;
    }

    public Course createCourse(String instructorId, String title, String description) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public Course getCourseById(String courseId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public List<Course> getAllCourses() {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public List<Course> getCoursesByInstructor(String instructorId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public void updateCourse(String courseId, String title, String description) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
