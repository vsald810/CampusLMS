package campuslms.course;

import campuslms.user.Instructor;

/** An academic course taught by one Instructor. */
public class Course {
    private String courseId;
    private String title;
    private String description;
    private Instructor instructor;

    public Course(String courseId, String title, String description, Instructor instructor) {
        this.courseId = courseId;
        this.title = title;
        this.description = description;
        this.instructor = instructor;
    }

    public String getCourseId() { return courseId; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Instructor getInstructor() { return instructor; }

    public void updateCourse(String title, String description) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
