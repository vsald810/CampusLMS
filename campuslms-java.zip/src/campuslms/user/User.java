package campuslms.user;

/** Abstract parent of all CampusLMS accounts (Student, Instructor, Administrator). */
public abstract class User {
    private String userId;
    private String fullName;
    private String email;
    private String passwordHash;
    private boolean active;

    protected User(String userId, String fullName, String email, String passwordHash) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.passwordHash = passwordHash;
        this.active = true;
    }

    public String getUserId() { return userId; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public boolean isActive() { return active; }

    public void updateProfile(String fullName, String email) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    /** Role contract implemented by each subclass, e.g. "STUDENT". */
    public abstract String getRole();
}
