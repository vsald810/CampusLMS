package campuslms.user;

/** A learner who enrolls in courses, submits work and views grades. */
public class Student extends User {

    public Student(String userId, String fullName, String email, String passwordHash) {
        super(userId, fullName, email, passwordHash);
    }

    @Override
    public String getRole() {
        return "STUDENT";
    }
}
