package campuslms.user;

import campuslms.repository.UserRepository;

/** Retrieves, updates and administers CampusLMS user accounts. */
public class UserService {
    private UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User getUserById(String userId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public User getUserByEmail(String email) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public void updateUserProfile(String userId, String fullName, String email) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public void deactivateUser(String userId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
