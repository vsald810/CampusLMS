package campuslms.user;

/** A teacher who manages courses and assignments and grades submissions. */
public class Instructor extends User {

    public Instructor(String userId, String fullName, String email, String passwordHash) {
        super(userId, fullName, email, passwordHash);
    }

    @Override
    public String getRole() {
        return "INSTRUCTOR";
    }
}
