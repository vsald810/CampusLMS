package campuslms.user;

/** A staff member who manages user accounts and course records. */
public class Administrator extends User {

    public Administrator(String userId, String fullName, String email, String passwordHash) {
        super(userId, fullName, email, passwordHash);
    }

    @Override
    public String getRole() {
        return "ADMINISTRATOR";
    }
}
