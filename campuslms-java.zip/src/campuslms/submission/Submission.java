package campuslms.submission;

import campuslms.assignment.Assignment;
import campuslms.user.Student;
import java.time.LocalDateTime;

/** Work submitted by one Student for one Assignment. */
public class Submission {
    private String submissionId;
    private Student student;
    private Assignment assignment;
    private LocalDateTime submittedAt;
    private String fileReference;

    public Submission(String submissionId, Student student, Assignment assignment,
                      LocalDateTime submittedAt, String fileReference) {
        this.submissionId = submissionId;
        this.student = student;
        this.assignment = assignment;
        this.submittedAt = submittedAt;
        this.fileReference = fileReference;
    }

    public String getSubmissionId() { return submissionId; }
    public Student getStudent() { return student; }
    public Assignment getAssignment() { return assignment; }
    public LocalDateTime getSubmittedAt() { return submittedAt; }
    public String getFileReference() { return fileReference; }
}
