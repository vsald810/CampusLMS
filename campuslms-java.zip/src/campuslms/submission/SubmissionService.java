package campuslms.submission;

import campuslms.assignment.AssignmentService;
import campuslms.enrollment.EnrollmentService;
import campuslms.notification.NotificationService;
import campuslms.repository.SubmissionRepository;
import campuslms.user.UserService;
import java.util.List;

/** Accepts and retrieves student submissions. */
public class SubmissionService {
    private SubmissionRepository submissionRepository;
    private UserService userService;
    private AssignmentService assignmentService;
    private EnrollmentService enrollmentService;
    private NotificationService notificationService;

    public SubmissionService(SubmissionRepository submissionRepository,
                             UserService userService,
                             AssignmentService assignmentService,
                             EnrollmentService enrollmentService,
                             NotificationService notificationService) {
        this.submissionRepository = submissionRepository;
        this.userService = userService;
        this.assignmentService = assignmentService;
        this.enrollmentService = enrollmentService;
        this.notificationService = notificationService;
    }

    public Submission submitAssignment(String studentId, String assignmentId, String fileReference) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public Submission getSubmission(String submissionId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public List<Submission> getAssignmentSubmissions(String assignmentId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }

    public List<Submission> getStudentSubmissions(String studentId) {
        throw new UnsupportedOperationException("Structural stub - business logic not required");
    }
}
